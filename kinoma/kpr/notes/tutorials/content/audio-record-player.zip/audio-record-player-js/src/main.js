var BUTTONS = require('buttons');
var Pins = require('pins');
var recordSkin = new Skin({ fill: 'red',});
var playSkin = new Skin({ fill: 'blue',});
var backgroundSkin = new Skin({ fill: 'white',});
var buttonLabelStyle = new Style({ color: 'black', font: 'bold 50px Helvetica, sans-serif', horizontal: 'center', vertical: 'null', });


var MainLine = new Line({ left: 10, right: 10, top: 10, bottom: 10, skin: backgroundSkin, behavior: Behavior({
	onCreate: function(line){
		var recordbutton = new BUTTONS.RecordButton({ left: 10, right: 10, top: 10, bottom: 10, active: true, 
			behavior: Behavior({
				onButtonTouchBegan: function(canvas) {
					Pins.invoke("/sounds/startRecording");
				},
				onButtonTouchEnded: function(canvas) {
					Pins.invoke("/sounds/stopRecording");
				}
			})  
		});
	
		var playbutton = new BUTTONS.PlayButton({ left: 10, right: 10, top: 10, bottom: 10, active: true, 
			behavior: Behavior({
				onButtonTouchBegan: function(canvas) {
					Pins.invoke("/sounds/stopPlay");
					Pins.invoke( "/sounds/playRecording");
				}
			})
		});
		line.add(recordbutton);
		line.add(playbutton);
	}
}) });

var ApplicationBehavior = Behavior.template({
	onLaunch: function(content) {
		Pins.configure({
    		sounds: {
        		require: "audioBLL",
        		pins: {
        			microphone: { sampleRate: 8000, channels: 1 },
        			speaker: { sampleRate: 8000, channels: 1 }
        		}
    		} 		
	    }, success => { 
	    	application.add( MainLine );
	    });
	}
});

application.behavior = new ApplicationBehavior();
